#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/select.h>
#include <netinet/in.h>

#define SERVER_PORT 4003
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

void run_server();

#endif // SERVER_H
