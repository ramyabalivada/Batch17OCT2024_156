#include <server.h>

int main() {
    run_server();
    return 0;
}
