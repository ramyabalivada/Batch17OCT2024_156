#include <stdio.h>
#include "calc.h"

int main()
{
	printf("\nAddition: %d\n",add(10,20));
	printf("\nSub: %d\n",sub(30,10));

	return 0;
}
