#ifndef CALC_H
#define CALC_H
#include <stdio.h>

int add(int,int);
int sub(int,int);

#endif
