A=10
B=20
#SUM=0 
SUM=`expr $A + $B`
#let sum=A+B
echo $SUM

