echo Program: $0
echo "no of args are"
echo $#
echo "all the args names"
echo $*
echo "1st arg is: "
echo $1
echo $$
