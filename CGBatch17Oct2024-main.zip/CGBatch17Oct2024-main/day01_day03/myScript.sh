echo "Welcome to Shell Scripting"
echo "Enter your name: "
read name
echo "Entered Name is : $name"

