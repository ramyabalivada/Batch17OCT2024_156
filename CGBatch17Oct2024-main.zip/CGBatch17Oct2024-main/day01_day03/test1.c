#include <stdio.h>

int main()
{
	int i=0;
	while(1)
	{
	}
	return 0;
}
