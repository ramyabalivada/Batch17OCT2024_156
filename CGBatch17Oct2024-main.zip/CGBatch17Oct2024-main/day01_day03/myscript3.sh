A="Bhima"
B="Bhima"

if ["$A" == "$B"] 
	then
		echo "Equal"
else
	echo "Not Equal"
fi
