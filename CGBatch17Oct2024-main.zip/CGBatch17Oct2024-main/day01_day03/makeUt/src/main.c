#include <stdio.h>
#include <calc.h>

int main()
{
	printf("\nAddition of two numbers: %d",add(10,20));
	printf("\nSub of two numbers: %d",sub(10,20));

	return 0;
}

