#ifndef CALC_H
#define CALC_H

//prototyping of functions
//decalre function prototypes

int add(int,int);
int sub(int, int);

#endif
