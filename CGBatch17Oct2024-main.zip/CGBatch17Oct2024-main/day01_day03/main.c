#include <stdio.h>

int main()
{
	int a;
	printf("\nHello ");
	return 0;
}
