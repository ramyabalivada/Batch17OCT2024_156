#include <stdio.h>

int main()
{
	
	int age;

	scanf("%d",&age);

	if(age>=18)
	{
		printf("\nYou are eligible to Vote");
	}
	else
	{
		printf("\nYou are not eligible to Vote");
	}
	printf("\nIndian Citizen\n");

	return 0;
}


