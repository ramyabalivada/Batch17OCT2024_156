#include <stdio.h>
#include <string.h>
#include <ctype.h>

int add(int, int);
int mul(int, int);
float div1(int, int);

int validName(char *);

char *getName();