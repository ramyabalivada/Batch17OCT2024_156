#include <stdio.h>
#include "file1.h"

int main()
{
	printf("\nAddtion of two numbers: %d",add(2,2));
	printf("\nMulti of two numbers: %d",mul(2,4));
	printf("\n\n");

	return 0;

}