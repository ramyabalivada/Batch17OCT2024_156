#ifndef ISPRIME_H
#define ISPRIME_H

#define True 1
#define False 0

int isPrime(int);


#endif