#include <stdio.h>
#include "mod4_func.h"

void mod4_func()
{
  printf("mod4_func() is called\n");
}
