#include <stdio.h>
#include "mod3_func.h"
#include "mod4_func.h"

void mod3_func()
{
  printf("mod3_func() is called\n");
  mod4_func();
}
