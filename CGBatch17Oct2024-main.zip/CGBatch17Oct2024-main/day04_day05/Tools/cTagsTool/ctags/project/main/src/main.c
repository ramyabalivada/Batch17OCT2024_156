#include <stdio.h>
#include "mod1_func.h"

int main()
{
  printf("main() started\n");
  mod1_func();

  return 0;
}
