#include <stdio.h>
#include <calc.h>

int main()
{
	printf("\nCalculator Application\n");
	printf("\nAddition of two numbers: %d",add(10,20));
	printf("\nSub of two numbers: %d",sub(10,20));
	printf("\nMultiplication of two numbers : %d",mul(2,3));
	printf("\ndivision of two numbers : %f",division(7,3));
	printf("\nCalculator Program Ends here\n");
	printf("\nEnd of Program\n");
	return 0;
}

