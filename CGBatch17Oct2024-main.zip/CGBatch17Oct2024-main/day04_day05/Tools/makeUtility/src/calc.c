#include <calc.h>

int add(int v1, int v2)
{
	return(v1+v2);
}

int sub(int v1, int v2)
{
	return (v1-v2);
}

int mul(int v1, int v2)
{
	return (v1*v2);
}

float division(int v1, int v2)
{
	return (v1/v2);
}
