splint is run on source codes

for example

$splint t2.c

which gives the output which shows if there is any unattended codes left

for example

int *ptr;
printf("%d",*ptr);

will show that dereferenced pointer is used before decalaration



