#include <stdio.h>
#include "mod1_bhima.h"
#include "mod2_bhima.h"

void mod1_func()
{
  printf("mod1_func() is called\n");
  mod2_func();
}
