#include <stdio.h>

int main()
{
	int i=0;
	int x=2;
	int y=4;

	for(i=0;i<3;i++)
	{
		printf("\nprod=%d\n",(x*y));
		y++;
	}

	return 0;
}

