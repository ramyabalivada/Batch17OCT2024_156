#include <stdio.h>

int main()
{
	int *ptr = NULL;
	*ptr = 10;

	printf("\nptr value = %d\n",*ptr);

	return 0;
}
