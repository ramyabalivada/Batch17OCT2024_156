#pragma once

#define MAX 5

int push(int);
int pop();
void dispStack();

int stackCont[MAX];

