git add .
git commit -m "updated"
git push origin main
echo "Done Git Push!"
